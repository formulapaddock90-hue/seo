<?php
/**
 * Template Name: Live Timing
 * Description: Template personalizzato a schermo intero per la trasmissione della telemetria e classifica F1 live su FormulaPaddock.
 */

get_header();

$options      = get_option('undercutf1_settings', array());
$accent_color = $options['accent_color'] ?? '#e10600';
$auto_refresh = intval($options['auto_refresh'] ?? 10) * 1000;
$standings    = get_option('undercutf1_current_standings', array());
$drivers      = $standings['drivers'] ?? array();
$session_name = $standings['sessionName'] ?? 'Live Timing F1';
$timestamp    = $standings['timestamp'] ?? date('Y-m-d H:i:s');
$is_live      = !empty($drivers) && (time() - strtotime($timestamp) < 300);
?>

<div id="live-timing-page-wrapper" style="
    background-color: #0e1015;
    color: #ffffff;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    padding: 30px 15px;
    min-height: 80vh;
">
    <div style="max-width: 1200px; margin: 0 auto;">

        <!-- HEADER BANNER PRINCIPALE TIPO FORMULAPADDOCK -->
        <div style="
            background: #161820;
            border: 1px solid #252836;
            border-top: 3px solid <?php echo esc_attr($accent_color); ?>;
            border-radius: 8px;
            padding: 20px 24px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        ">
            <div style="display: flex; align-items: center; gap: 14px;">
                <span style="background: <?php echo esc_attr($accent_color); ?>; color: #fff; padding: 6px 12px; border-radius: 4px; font-weight: 900; font-size: 1rem; letter-spacing: 1px;">F1</span>
                <div>
                    <h1 style="margin: 0; color: #ffffff; font-weight: 900; font-size: 1.4rem; text-transform: uppercase; letter-spacing: 0.5px; line-height: 1.2;">
                        LIVE TIMING F1 – TELEMETRIA IN DIRETTA
                    </h1>
                    <p style="margin: 4px 0 0 0; color: #8e929b; font-size: 0.85rem; font-weight: 600;">FORMULA PADDOCK - DIRECT STREAM</p>
                </div>
            </div>

            <div>
                <?php if ($is_live) : ?>
                    <span style="background: rgba(39, 174, 96, 0.15); border: 1px solid #27ae60; color: #2ecc71; padding: 8px 16px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; letter-spacing: 0.5px; display: inline-flex; align-items: center; gap: 8px;">
                        <span style="width: 8px; height: 8px; background: #2ecc71; border-radius: 50%; display: inline-block; box-shadow: 0 0 8px #2ecc71;"></span> LIVE - TRANSMITTING
                    </span>
                <?php else : ?>
                    <span style="background: rgba(225, 6, 0, 0.15); border: 1px solid <?php echo esc_attr($accent_color); ?>; color: <?php echo esc_attr($accent_color); ?>; padding: 8px 16px; border-radius: 20px; font-weight: 800; font-size: 0.85rem; letter-spacing: 0.5px; display: inline-flex; align-items: center; gap: 8px;">
                        <span style="width: 8px; height: 8px; background: <?php echo esc_attr($accent_color); ?>; border-radius: 50%; display: inline-block;"></span> OFFLINE - NO SESSION ACTIVE
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <!-- SCHEDA CLASSIFICA E TELEMETRIA -->
        <?php echo do_shortcode('[formulapaddock_classifica]'); ?>

        <!-- PROGRAMMAZIONE TRASMISSIONE TELEMETRIA F1 -->
        <div style="
            background: #161820;
            border: 1px solid #252836;
            border-radius: 8px;
            padding: 24px;
            margin-top: 24px;
        ">
            <h4 style="margin: 0 0 16px 0; color: #ffffff; font-size: 1rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 8px;">
                <span>📅</span> PROGRAMMAZIONE TRASMISSIONE TELEMETRIA F1
            </h4>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
                <div style="background: #101218; border: 1px solid #252836; border-left: 3px solid <?php echo esc_attr($accent_color); ?>; border-radius: 6px; padding: 16px;">
                    <div style="color: <?php echo esc_attr($accent_color); ?>; font-weight: 900; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">VENERDÌ</div>
                    <div style="color: #ffffff; font-weight: 700; margin-top: 4px;">Prove Libere 1 & 2</div>
                </div>

                <div style="background: #101218; border: 1px solid #252836; border-left: 3px solid <?php echo esc_attr($accent_color); ?>; border-radius: 6px; padding: 16px;">
                    <div style="color: <?php echo esc_attr($accent_color); ?>; font-weight: 900; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">SABATO</div>
                    <div style="color: #ffffff; font-weight: 700; margin-top: 4px;">FP3 & Qualifiche / Sprint</div>
                </div>

                <div style="background: #101218; border: 1px solid #252836; border-left: 3px solid <?php echo esc_attr($accent_color); ?>; border-radius: 6px; padding: 16px;">
                    <div style="color: <?php echo esc_attr($accent_color); ?>; font-weight: 900; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">DOMENICA</div>
                    <div style="color: #ffffff; font-weight: 700; margin-top: 4px;">Gran Premio (Gara Live)</div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php
get_footer();
