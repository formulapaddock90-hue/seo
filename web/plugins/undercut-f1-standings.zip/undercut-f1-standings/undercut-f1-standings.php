<?php
/**
 * Plugin Name: FormulaPaddock UndercutF1 Integration
 * Plugin URI: https://www.formulapaddock.it
 * Description: Gestione e sincronizzazione in tempo reale delle classifiche F1 dal PC locale ad /wp-admin tramite Webhook REST API.
 * Version: 1.0.0
 * Author: UndercutF1 Team
 * Text Domain: undercut-f1-standings
 */

if (!defined('ABSPATH')) {
    exit; // Protezione accesso diretto
}

class UndercutF1_Standings_Plugin {

    private static $instance = null;
    private $option_key = 'undercutf1_settings';
    private $data_key   = 'undercutf1_current_standings';
    private $logs_key   = 'undercutf1_webhook_logs';

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Registrazione Endpoint REST API
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // Menu Amministrazione /wp-admin
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Inizializzazione opzioni predefinite
        add_action('admin_init', array($this, 'register_settings'));

        // Registrazione Shortcode
        add_shortcode('formulapaddock_classifica', array($this, 'render_shortcode'));

        // Script ed elementi grafici in wp-admin
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // Registrazione Template Pagina WordPress "Live Timing"
        add_filter('theme_page_templates', array($this, 'register_live_timing_template'), 10, 4);
        add_filter('template_include', array($this, 'load_live_timing_template_file'));
    }

    /**
     * Registra il template "Live Timing" nel menu a tendina "Attributi pagina" in /wp-admin
     */
    public function register_live_timing_template($post_templates, $wp_theme, $post, $post_type) {
        $post_templates['template-live-timing.php'] = 'Live Timing';
        return $post_templates;
    }

    /**
     * Inserisce il layout completo per la pagina quando il template "Live Timing" è selezionato
     */
    public function load_live_timing_template_file($template) {
        if (is_page()) {
            $meta_template = get_post_meta(get_the_ID(), '_wp_page_template', true);
            if ($meta_template === 'template-live-timing.php') {
                return __DIR__ . '/template-live-timing.php';
            }
        }
        return $template;
    }


    /**
     * Inizializzazione impostazioni predefinite
     */
    public function register_settings() {
        register_setting($this->option_key, $this->option_key);

        $default_options = array(
            'api_key'      => bin2hex(random_bytes(16)),
            'accent_color' => '#e10600',
            'dark_mode'    => '1',
            'auto_refresh' => '10'
        );

        if (!get_option($this->option_key)) {
            add_option($this->option_key, $default_options);
        }
    }

    /**
     * Registrazione Rotte REST API
     */
    public function register_rest_routes() {
        register_rest_route('undercutf1/v1', '/update-standings', array(
            array(
                'methods'             => 'POST',
                'callback'            => array($this, 'handle_webhook_update'),
                'permission_callback' => array($this, 'verify_api_key'),
            ),
            array(
                'methods'             => 'GET',
                'callback'            => array($this, 'handle_get_standings'),
                'permission_callback' => '__return_true',
            )
        ));
    }

    /**
     * Verifica della Chiave API nell'Header HTTP (X-API-Key) o parametro URL
     */
    public function verify_api_key($request) {
        $options = get_option($this->option_key);
        $configured_key = isset($options['api_key']) ? trim($options['api_key']) : '';

        if (empty($configured_key)) {
            return true; // Se nessuna chiave impostata, consenti
        }

        $provided_key = $request->get_header('X-API-Key');
        if (empty($provided_key)) {
            $provided_key = $request->get_param('api_key');
        }

        if (trim($provided_key) === $configured_key) {
            return true;
        }

        return new WP_Error('rest_forbidden', 'Chiave API non valida o non autorizzata.', array('status' => 401));
    }

    /**
     * Webhook POST Endpoint Callback
     */
    public function handle_webhook_update($request) {
        $body = $request->get_json_params();

        if (empty($body)) {
            $body = json_decode($request->get_body(), true);
        }

        if (empty($body)) {
            return new WP_Error('invalid_payload', 'Payload JSON non valido o vuoto', array('status' => 400));
        }

        $drivers = array();
        if (isset($body['drivers']) && is_array($body['drivers'])) {
            $drivers = $body['drivers'];
        } elseif (isset($body['csvData'])) {
            $drivers = $this->parse_csv_data($body['csvData']);
        } elseif (is_array($body) && isset($body[0])) {
            $drivers = $body;
        }

        $session_name = isset($body['sessionName']) ? sanitize_text_field($body['sessionName']) : 'Gara / Live Timing';
        $timestamp = date('Y-m-d H:i:s');

        $payload_data = array(
            'sessionName' => $session_name,
            'drivers'     => $drivers,
            'count'       => count($drivers),
            'timestamp'   => $timestamp,
            'updated_by'  => 'PC Locale Webhook'
        );

        // Salva classifica in wp_options
        update_option($this->data_key, $payload_data);

        // Salva log attività webhook
        $this->add_log_entry(array(
            'timestamp' => $timestamp,
            'status'    => 'SUCCESS',
            'session'   => $session_name,
            'drivers'   => count($drivers),
            'ip'        => $_SERVER['REMOTE_ADDR'] ?? 'PC Locale'
        ));

        return rest_ensure_response(array(
            'success'   => true,
            'message'   => 'Classifica aggiornata con successo su WordPress!',
            'count'     => count($drivers),
            'timestamp' => $timestamp
        ));
    }

    /**
     * GET Endpoint Callback
     */
    public function handle_get_standings($request) {
        $data = get_option($this->data_key);

        if (empty($data)) {
            return rest_ensure_response(array(
                'success' => false,
                'error'   => 'Nessuna classifica ancora salvata.',
                'data'    => array()
            ));
        }

        return rest_ensure_response(array_merge(array('success' => true), $data));
    }

    /**
     * Aggiunge un record nel registro log
     */
    private function add_log_entry($entry) {
        $logs = get_option($this->logs_key, array());
        if (!is_array($logs)) $logs = array();

        array_unshift($logs, $entry);
        $logs = array_slice($logs, 0, 50); // Mantiene gli ultimi 50 log

        update_option($this->logs_key, $logs);
    }

    /**
     * Menu Amministrazione WordPress (/wp-admin)
     */
    public function add_admin_menu() {
        add_menu_page(
            'FormulaPaddock UndercutF1',
            'UndercutF1 Live',
            'manage_options',
            'undercut-f1-standings',
            array($this, 'render_admin_page'),
            'dashicons-flag',
            30
        );
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_undercut-f1-standings') return;
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }

    /**
     * Render della pagina /wp-admin/admin.php?page=undercut-f1-standings
     */
    public function render_admin_page() {
        if (!current_user_can('manage_options')) return;

        // Salvataggio form se inviato
        if (isset($_POST['undercutf1_save_settings']) && check_admin_referer('undercutf1_settings_verify')) {
            $options = array(
                'api_key'      => sanitize_text_field($_POST['api_key']),
                'accent_color' => sanitize_hex_color($_POST['accent_color']),
                'dark_mode'    => isset($_POST['dark_mode']) ? '1' : '0',
                'auto_refresh' => intval($_POST['auto_refresh'])
            );
            update_option($this->option_key, $options);
            echo '<div class="notice notice-success is-dismissible"><p>✅ Impostazioni UndercutF1 salvate con successo!</p></div>';
        }

        // Reset dati di prova
        if (isset($_POST['undercutf1_clear_logs']) && check_admin_referer('undercutf1_settings_verify')) {
            update_option($this->logs_key, array());
            echo '<div class="notice notice-info is-dismissible"><p>🗑️ Registro log webhook svuotato.</p></div>';
        }

        $options   = get_option($this->option_key, array());
        $standings = get_option($this->data_key, array());
        $logs      = get_option($this->logs_key, array());

        $api_key      = $options['api_key'] ?? '';
        $accent_color = $options['accent_color'] ?? '#e10600';
        $dark_mode    = ($options['dark_mode'] ?? '1') === '1';
        $auto_refresh = $options['auto_refresh'] ?? 10;
        $webhook_url  = get_rest_url(null, 'undercutf1/v1/update-standings');
        ?>
        <div class="wrap">
            <h1 style="display:flex; align-items:center; gap:10px;">
                <span style="background:<?php echo esc_attr($accent_color); ?>; color:#fff; padding:4px 10px; border-radius:4px;">F1</span>
                FormulaPaddock UndercutF1 — Pannello di Controllo
            </h1>
            <p class="description">Gestisci la sincronizzazione in tempo reale dal tuo PC locale verso la pagina <code>https://www.formulapaddock.it/live-timing-f1/</code>.</p>

            <h2 class="nav-tab-wrapper">
                <a href="#tab-settings" class="nav-tab nav-tab-active" onclick="switchTab(event, 'tab-settings')">⚙️ Impostazioni API & Webhook</a>
                <a href="#tab-preview" class="nav-tab" onclick="switchTab(event, 'tab-preview')">📊 Anteprima Classifica Live</a>
                <a href="#tab-logs" class="nav-tab" onclick="switchTab(event, 'tab-logs')">📋 Log Registro Webhook (<?php echo count($logs); ?>)</a>
            </h2>

            <form method="post" action="">
                <?php wp_nonce_field('undercutf1_settings_verify'); ?>

                <!-- TAB 1: IMPOSTAZIONI -->
                <div id="tab-settings" class="tab-content-panel" style="margin-top:20px;">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="webhook_url">Endpoint REST Webhook (in UndercutF1 PC)</label></th>
                            <td>
                                <input type="text" id="webhook_url" readonly class="regular-text" value="<?php echo esc_url($webhook_url); ?>" onclick="this.select()" />
                                <p class="description">Copia questo URL nella configurazione di UndercutF1 sul tuo PC locale.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="api_key">Chiave API Segreta (X-API-Key)</label></th>
                            <td>
                                <input type="text" name="api_key" id="api_key" class="regular-text" value="<?php echo esc_attr($api_key); ?>" />
                                <button type="button" class="button" onclick="document.getElementById('api_key').value = Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2)">Rigenera Chiave</button>
                                <p class="description">Inserisci questo valore nell'header HTTP <code>X-API-Key</code> dell'applicazione .NET.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="accent_color">Colore Accento F1</label></th>
                            <td>
                                <input type="text" name="accent_color" id="accent_color" class="wp-color-picker-field" value="<?php echo esc_attr($accent_color); ?>" />
                                <p class="description">Colore per il bordo superiore, i badge e i pulsanti (Default F1 Red: <code>#e10600</code>).</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="auto_refresh">Frequenza Refresh (secondi)</label></th>
                            <td>
                                <input type="number" name="auto_refresh" id="auto_refresh" min="2" max="60" value="<?php echo esc_attr($auto_refresh); ?>" />
                                <p class="description">Intervallo di aggiornamento automatico della tabella nel front-end.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Shortcode Inserimento</th>
                            <td>
                                <code>[formulapaddock_classifica]</code>
                                <p class="description">Incolla questo shortcode in qualsiasi pagina o blocco Gutenberg per mostrare la classifica.</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button('Salva Impostazioni', 'primary', 'undercutf1_save_settings'); ?>
                </div>

                <!-- TAB 2: ANTEPRIMA CLASSIFICA -->
                <div id="tab-preview" class="tab-content-panel" style="display:none; margin-top:20px;">
                    <h3>🏆 Ultima Classifica Ricevuta</h3>
                    <?php if (!empty($standings['drivers'])) : ?>
                        <p>Sessione: <strong><?php echo esc_html($standings['sessionName'] ?? 'Sessione Live'); ?></strong> — Ultimo aggiornamento: <code><?php echo esc_html($standings['timestamp'] ?? '-'); ?></code> (Piloti: <?php echo count($standings['drivers']); ?>)</p>
                        <table class="wp-list-table widefat fixed striped" style="background:#161820; color:#fff; border-top:3px solid <?php echo esc_attr($accent_color); ?>;">
                            <thead>
                                <tr style="background:#101218; color:<?php echo esc_attr($accent_color); ?>;">
                                    <th style="width:50px;">Pos</th>
                                    <th style="width:50px;">N.</th>
                                    <th>Pilota</th>
                                    <th>Team</th>
                                    <th>Best Lap</th>
                                    <th>Ultimo Giro</th>
                                    <th style="width:60px;">Giri</th>
                                    <th>Gap</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($standings['drivers'] as $idx => $d) : ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($d['position'] ?? $d['Posizione'] ?? ($idx + 1)); ?></strong></td>
                                        <td><?php echo esc_html($d['carNumber'] ?? $d['N. Gara'] ?? $d['number'] ?? '-'); ?></td>
                                        <td><strong><?php echo esc_html($d['driverName'] ?? $d['Pilota'] ?? $d['driver'] ?? '-'); ?></strong></td>
                                        <td><?php echo esc_html($d['teamName'] ?? $d['Team'] ?? $d['team'] ?? '-'); ?></td>
                                        <td><?php echo esc_html($d['bestLap'] ?? $d['Best Lap'] ?? '-'); ?></td>
                                        <td><?php echo esc_html($d['lastLap'] ?? $d['Ultimo Giro'] ?? '-'); ?></td>
                                        <td><?php echo esc_html($d['laps'] ?? $d['Giri'] ?? '-'); ?></td>
                                        <td><?php echo esc_html($d['gap'] ?? $d['Gap'] ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div class="notice notice-warning inline"><p>Nessun dato di classifica ancora ricevuto dal PC locale. Avvia UndercutF1 per inviare i primi dati.</p></div>
                    <?php endif; ?>
                </div>

                <!-- TAB 3: LOG REGISTRO WEBHOOK -->
                <div id="tab-logs" class="tab-content-panel" style="display:none; margin-top:20px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <h3>📋 Registro Attività Webhook (Ultime 50 chiamate)</h3>
                        <submit_button>
                        <button type="submit" name="undercutf1_clear_logs" class="button button-secondary" onclick="return confirm('Confermi lo svuotamento dei log?')">🗑️ Svuota Registro Log</button>
                    </div>
                    <?php if (!empty($logs)) : ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th>Data e Ora</th>
                                    <th>Stato</th>
                                    <th>Sessione</th>
                                    <th>Piloti</th>
                                    <th>IP Sorgente</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $log) : ?>
                                    <tr>
                                        <td><code><?php echo esc_html($log['timestamp']); ?></code></td>
                                        <td><span class="badge" style="background:#27ae60; color:#fff; padding:2px 8px; border-radius:3px; font-weight:bold; font-size:11px;"><?php echo esc_html($log['status']); ?></span></td>
                                        <td><?php echo esc_html($log['session']); ?></td>
                                        <td><?php echo esc_html($log['drivers']); ?> piloti</td>
                                        <td><code><?php echo esc_html($log['ip']); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <p class="description">Il registro attività webhook è attualmente vuoto.</p>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <script>
            function switchTab(evt, tabId) {
                evt.preventDefault();
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tab-content-panel");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("nav-tab");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" nav-tab-active", "");
                }
                document.getElementById(tabId).style.display = "block";
                evt.currentTarget.className += " nav-tab-active";
            }

            jQuery(document.documentElement).ready(function($){
                if ($.fn.wpColorPicker) {
                    $('.wp-color-picker-field').wpColorPicker();
                }
            });
        </script>
        <?php
    }

    /**
     * Rendering dello Shortcode [formulapaddock_classifica] per la pagina /live-timing-f1/
     */
    public function render_shortcode($atts) {
        $options      = get_option($this->option_key, array());
        $accent_color = $options['accent_color'] ?? '#e10600';
        $auto_refresh = intval($options['auto_refresh'] ?? 10) * 1000;
        $standings    = get_option($this->data_key, array());
        $drivers      = $standings['drivers'] ?? array();
        $session_name = $standings['sessionName'] ?? 'Live Timing F1';
        $timestamp    = $standings['timestamp'] ?? date('Y-m-d H:i:s');

        ob_start();
        ?>
        <div id="formulapaddock-standings-wrapper" class="formulapaddock-live-standings-card" style="
            background: #161820;
            border: 1px solid #252836;
            border-top: 3px solid <?php echo esc_attr($accent_color); ?>;
            border-radius: 8px;
            padding: 24px;
            color: #ffffff;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 25px auto;
            max-width: 1200px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        ">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px; margin-bottom: 20px; border-bottom: 1px solid #252836; padding-bottom: 16px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="background: <?php echo esc_attr($accent_color); ?>; color: #ffffff; padding: 4px 10px; border-radius: 4px; font-weight: 900; font-size: 0.9rem; letter-spacing: 1px;">F1</span>
                    <div>
                        <h3 style="margin: 0; color: #ffffff; font-weight: 800; font-size: 1.25rem; text-transform: uppercase; letter-spacing: 0.5px;">
                            CLASSIFICA FINALE & TELEMETRIA UNDERCUTF1
                        </h3>
                        <p style="margin: 4px 0 0 0; color: #8e929b; font-size: 0.85rem;" id="fp-session-title">Sessione: <?php echo esc_html($session_name); ?></p>
                    </div>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="button" id="import-local-standings" style="
                        background: <?php echo esc_attr($accent_color); ?>;
                        color: #ffffff;
                        border: none;
                        padding: 10px 20px;
                        font-weight: 800;
                        font-size: 0.85rem;
                        border-radius: 4px;
                        cursor: pointer;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                        box-shadow: 0 4px 12px rgba(225, 6, 0, 0.35);
                    ">
                        🏁 AGGIORNA CLASSIFICA
                    </button>
                </div>
            </div>

            <div id="modulo-d-status" style="padding: 12px 16px; border-radius: 4px; margin-bottom: 16px; font-size: 0.9rem; display: none;"></div>

            <div style="overflow-x: auto; border-radius: 6px; border: 1px solid #252836;">
                <table id="classifica-finale" style="width: 100%; border-collapse: collapse; background: #14161f; color: #ffffff; font-size: 0.9rem;">
                    <thead style="background: #101218; color: #8e929b; text-transform: uppercase; font-size: 0.75rem; font-weight: 800; border-bottom: 2px solid <?php echo esc_attr($accent_color); ?>;">
                        <tr>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836; width: 60px;">POS</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836; width: 50px;">N.</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836;">PILOTA</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836;">TEAM</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836;">BEST LAP</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836;">ULTIMO GIRO</th>
                            <th style="padding: 12px; text-align: left; border-right: 1px solid #252836; width: 60px;">GIRI</th>
                            <th style="padding: 12px; text-align: left;">GAP</th>
                        </tr>
                    </thead>
                    <tbody id="classifica-finale-body">
                        <?php if (!empty($drivers)) : ?>
                            <?php foreach ($drivers as $idx => $row) : ?>
                                <tr style="border-bottom: 1px solid #1f222e; background: <?php echo ($idx % 2 === 0) ? '#181b24' : '#14161f'; ?>;">
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><strong style="color: <?php echo esc_attr($accent_color); ?>;"><?php echo esc_html($row['position'] ?? $row['Posizione'] ?? ($idx + 1)); ?></strong></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><?php echo esc_html($row['carNumber'] ?? $row['N. Gara'] ?? $row['number'] ?? '-'); ?></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><strong><?php echo esc_html($row['driverName'] ?? $row['Pilota'] ?? $row['driver'] ?? '-'); ?></strong></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><?php echo esc_html($row['teamName'] ?? $row['Team'] ?? $row['team'] ?? '-'); ?></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><?php echo esc_html($row['bestLap'] ?? $row['Best Lap'] ?? '-'); ?></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><?php echo esc_html($row['lastLap'] ?? $row['Ultimo Giro'] ?? '-'); ?></td>
                                    <td style="padding: 10px 12px; border-right: 1px solid #252836;"><?php echo esc_html($row['laps'] ?? $row['Giri'] ?? '-'); ?></td>
                                    <td style="padding: 10px 12px;"><?php echo esc_html($row['gap'] ?? $row['Gap'] ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="8" style="padding: 30px; text-align: center; color: #8e929b;">
                                    In attesa della sincronizzazione della classifica dal PC locale UndercutF1...
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div id="modulo-d-timestamp" style="text-align: right; color: #8e929b; font-size: 0.8rem; margin-top: 12px; font-style: italic;">
                Ultimo aggiornamento: <?php echo esc_html($timestamp); ?>
            </div>
        </div>

        <script>
            (function() {
                const restEndpoint = '<?php echo esc_url(get_rest_url(null, "undercutf1/v1/update-standings")); ?>';
                const refreshInterval = <?php echo intval($auto_refresh); ?>;

                async function refreshStandings() {
                    try {
                        const res = await fetch(restEndpoint);
                        const json = await res.json();
                        if (json && json.success && json.drivers) {
                            renderTable(json.drivers, json.sessionName, json.timestamp);
                        }
                    } catch (e) {
                        console.log('UndercutF1 Polling error:', e);
                    }
                }

                function renderTable(drivers, sessionName, timestamp) {
                    const tbody = document.getElementById('classifica-finale-body');
                    const tsEl = document.getElementById('modulo-d-timestamp');
                    const sessionEl = document.getElementById('fp-session-title');

                    if (sessionEl && sessionName) sessionEl.textContent = 'Sessione: ' + sessionName;
                    if (tsEl && timestamp) tsEl.textContent = 'Ultimo aggiornamento: ' + timestamp;

                    if (!tbody || !drivers) return;
                    tbody.innerHTML = '';

                    drivers.forEach((row, idx) => {
                        const tr = document.createElement('tr');
                        tr.style.cssText = 'border-bottom: 1px solid #1f222e; background: ' + (idx % 2 === 0 ? '#181b24' : '#14161f') + ';';
                        tr.innerHTML = `
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;"><strong style="color:<?php echo esc_js($accent_color); ?>;">${row.position || row.Posizione || (idx+1)}</strong></td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;">${row.carNumber || row['N. Gara'] || row.number || '-'}</td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;"><strong>${row.driverName || row.Pilota || row.driver || '-'}</strong></td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;">${row.teamName || row.Team || row.team || '-'}</td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;">${row.bestLap || row['Best Lap'] || '-'}</td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;">${row.lastLap || row['Ultimo Giro'] || '-'}</td>
                            <td style="padding: 10px 12px; border-right: 1px solid #252836;">${row.laps || row.Giri || '-'}</td>
                            <td style="padding: 10px 12px;">${row.gap || row.Gap || '-'}</td>
                        `;
                        tbody.appendChild(tr);
                    });
                }

                document.addEventListener('DOMContentLoaded', function() {
                    const btn = document.getElementById('import-local-standings');
                    if (btn) btn.addEventListener('click', refreshStandings);
                    if (refreshInterval > 0) {
                        setInterval(refreshStandings, refreshInterval);
                    }
                });
            })();
        </script>
        <?php
        return ob_get_clean();
    }

    private function parse_csv_data($csv) {
        $lines = explode("\n", $csv);
        $result = array();
        $headers = array();
        foreach ($lines as $i => $line) {
            $line = trim($line);
            if (empty($line)) continue;
            $delim = (strpos($line, ';') !== false) ? ';' : ',';
            if ($i === 0) {
                $headers = str_getcsv($line, $delim);
                continue;
            }
            $cols = str_getcsv($line, $delim);
            $row = array();
            foreach ($headers as $idx => $h) {
                $row[trim($h)] = trim($cols[$idx] ?? '');
            }
            $result[] = $row;
        }
        return $result;
    }
}

// Inizializzazione Plugin
UndercutF1_Standings_Plugin::get_instance();
